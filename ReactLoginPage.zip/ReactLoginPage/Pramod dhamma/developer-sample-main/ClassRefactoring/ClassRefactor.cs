using System;

namespace DeveloperSample.ClassRefactoring
{
    public enum SwallowType
    {
        African, European
    }

    public enum SwallowLoad
    {
        None, Coconut
    }

    public class SwallowFactory
    {
        public Swallow GetSwallow(SwallowType swallowType) 
        {
            return swallowType switch
            {
                SwallowType.African => new AfricanSwallow(),
                SwallowType.European => new EuropeanSwallow(),
                _ => throw new ArgumentException($"Unknown swallow type: {swallowType}", nameof(swallowType))
            };
        }
    }

    public abstract class Swallow
    {
        public abstract SwallowType Type { get; }
        public SwallowLoad Load { get; private set; } = SwallowLoad.None;

        public void ApplyLoad(SwallowLoad load)
        {
            Load = load;
        }

        public double GetAirspeedVelocity()
        {
            return Load == SwallowLoad.None ? GetBaseAirspeedVelocity() : GetLoadedAirspeedVelocity();
        }

        protected abstract double GetBaseAirspeedVelocity();
        protected abstract double GetLoadedAirspeedVelocity();
    }

    public class AfricanSwallow : Swallow
    {
        public override SwallowType Type => SwallowType.African;

        protected override double GetBaseAirspeedVelocity() => 22;
        protected override double GetLoadedAirspeedVelocity() => 18;
    }

    public class EuropeanSwallow : Swallow
    {
        public override SwallowType Type => SwallowType.European;

        protected override double GetBaseAirspeedVelocity() => 20;
        protected override double GetLoadedAirspeedVelocity() => 16;
    }
}
