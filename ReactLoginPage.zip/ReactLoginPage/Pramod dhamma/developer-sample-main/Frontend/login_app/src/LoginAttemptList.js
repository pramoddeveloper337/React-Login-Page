import React, { useState } from "react";
import "./LoginAttemptList.css";

const LoginAttempt = ({ attempt }) => {
	const statusClass = attempt.successful ? "success" : "failure";
	return (
		<li className={`attempt ${statusClass}`}>
			<span className="timestamp">{attempt.timestamp}</span>
			<span className="username">{attempt.login || "(empty)"}</span>
			<span className="password">{attempt.password}</span>
			<span className="status">{attempt.successful ? "✓" : "✗"}</span>
		</li>
	);
};

const LoginAttemptList = ({ attempts = [] }) => {
	const [filter, setFilter] = useState("");
	
	const filteredAttempts = attempts.filter(attempt => 
		attempt.login?.toLowerCase().includes(filter.toLowerCase()) ||
		attempt.timestamp?.toLowerCase().includes(filter.toLowerCase())
	);

	return (
		<div className="Attempt-List-Main">
			<p>Recent activity</p>
			<input 
				type="input" 
				placeholder="Filter..." 
				value={filter}
				onChange={(e) => setFilter(e.target.value)}
			/>
			<ul className="Attempt-List">
				{filteredAttempts.length > 0 ? (
					filteredAttempts.map(attempt => (
						<LoginAttempt key={attempt.id} attempt={attempt} />
					))
				) : (
					<li className="no-attempts">No login attempts yet</li>
				)}
			</ul>
		</div>
	);
};

export default LoginAttemptList;