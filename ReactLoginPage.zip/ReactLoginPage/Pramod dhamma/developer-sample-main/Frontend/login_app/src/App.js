import React, { useState } from "react";
import './App.css';
import LoginForm from './LoginForm';
import LoginAttemptList from './LoginAttemptList';

const App = () => {
  const [loginAttempts, setLoginAttempts] = useState([]);

  const handleLoginAttempt = ({ login, password }) => {
    const timestamp = new Date().toLocaleTimeString();
    const newAttempt = {
      id: Date.now(),
      timestamp,
      login,
      password: '•'.repeat(password.length),
      successful: login && password && password.length >= 6
    };
    
    setLoginAttempts(prevAttempts => [newAttempt, ...prevAttempts]);
  };

  return (
    <div className="App">
      <LoginForm onSubmit={handleLoginAttempt} />
      <LoginAttemptList attempts={loginAttempts} />
    </div>
  );
};

export default App;
