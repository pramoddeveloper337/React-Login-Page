using System;
using System.Collections.Generic;

namespace DeveloperSample.Container
{
    public class Container
    {
        private readonly Dictionary<Type, Type> _bindings = new Dictionary<Type, Type>();
        
        public void Bind(Type interfaceType, Type implementationType)
        {
            if (interfaceType == null)
                throw new ArgumentNullException(nameof(interfaceType));
                
            if (implementationType == null)
                throw new ArgumentNullException(nameof(implementationType));
                
            if (!implementationType.IsClass)
                throw new ArgumentException("Implementation type must be a class", nameof(implementationType));
                
            if (interfaceType.IsClass && !implementationType.IsSubclassOf(interfaceType))
                throw new ArgumentException($"{implementationType.Name} does not inherit from {interfaceType.Name}");
                
            if (interfaceType.IsInterface && !interfaceType.IsAssignableFrom(implementationType))
                throw new ArgumentException($"{implementationType.Name} does not implement {interfaceType.Name}");
                
            _bindings[interfaceType] = implementationType;
        }
        
        public T Get<T>()
        {
            var type = typeof(T);
            
            if (!_bindings.TryGetValue(type, out var implementationType))
                throw new InvalidOperationException($"No binding found for {type.Name}");
                
            return (T)Activator.CreateInstance(implementationType);
        }
    }
}
